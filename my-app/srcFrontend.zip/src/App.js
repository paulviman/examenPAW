import logo from './logo.svg';
import './App.css';
import React from 'react';
import {BrowserRouter as Router, Route, Routes} from 'react-router-dom';
import BookSearch from './BookSearch';
import * as PropTypes from "prop-types";
import HomePage from "./HomePage";

function Switch(props) {
    return null;
}

Switch.propTypes = {children: PropTypes.node};

function App() {
  return (
      <div><Router>
          <Route path='/' exact component={HomePage}></Route>
          <Routes path="/book-search" component={BookSearch} />
      </Router></div>

    // <Switch>
    //
    //     {/* Add more routes here */}
    // </Switch>
  );
}

export default App;
