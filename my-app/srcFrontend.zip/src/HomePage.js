import React, { Component } from 'react';
import { withRouter } from 'react-router-dom';

class HomePage extends Component {
    handleSearch = () => {
        const { history } = this.props;
        history.push('/book-search');
    };

    render() {
        return (
            <div>
                <h1>Welcome to the Book Search App</h1>
                <button onClick={this.handleSearch}>Search for Books</button>
            </div>
        );
    }
}

export default HomePage;